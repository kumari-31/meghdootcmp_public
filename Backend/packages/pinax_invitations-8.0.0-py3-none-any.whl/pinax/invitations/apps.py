import importlib

from django.apps import AppConfig as BaseAppConfig
from django.utils.translation import gettext_lazy as _


class AppConfig(BaseAppConfig):

    name = "pinax.invitations"
    label = "pinax_invitations"
    verbose_name = _("Pinax Invitations")

    def ready(self):
        importlib.import_module("pinax.invitations.receivers")
